<?php $__env->startSection('content'); ?>

<!-- Main Content Area -->
<div class="main-content introduction-farm">
    <div class="content-wraper-area">
        <div class="dashboard-area">
            <div class="container-fluid">
                <div class="row g-4">

                    <?php if(Session::has('error_msg')): ?>
                    <div class="alert alert-danger"> <?php echo e(Session::get('error_msg')); ?> </div>
                    <?php endif; ?>

                    <?php if(Session::has('success_msg')): ?>
                    <div class="alert alert-success"> <?php echo e(Session::get('success_msg')); ?> </div>
                    <?php endif; ?>
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div
                                    class="card-title border-bootom-none mb-30 d-flex align-items-center justify-content-between">
                                    <h3 class="mb-0 ct_fs_22">Edit Featherweight</h3>
                                    <a href="<?php echo e(url('cms/weight-classes/featherweight-list')); ?>"> <button class="ct_custom_btn1 mx-auto"> Back to List </button> </a>
                                </div>
                                <form action="<?php echo e(url('cms/weight-classes/featherweight-update')); ?>" method="POST" id="editThinkercad" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo e($featherweightData->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="weight_class_title" class="mb-2">Weight Class Title</label>
                                                <input type="text" class="form-control ct_input" name="weight_class_title" placeholder="Weight Class Title" value="<?php echo e(old('weight_class_title', $featherweightData->weight_class_title)); ?>">
                                                <?php $__errorArgs = ['weight_class_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="weight_class_description" class="mb-2">Weight Class Description</label>
                                                <textarea rows="4" class="form-control" name="weight_class_description" id="weight_class_description" placeholder="Weight Class Description"><?php echo e(old('weight_class_description', $featherweightData->weight_class_description)); ?></textarea>
                                                <?php $__errorArgs = ['weight_class_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="weight_class_image" class="mb-2">Weight Class Image</label>
                                                <input name="weight_class_image" type="file" class="form-control ct_input" onchange="loadWeightClassImage(event)" accept="image/*">

                                                <?php if(!empty($featherweightData->weight_class_image) && file_exists(public_path('cms_images/weight/featherweights/' . $featherweightData->weight_class_image))): ?>

                                                <div id="imagePreviewWrapper" class="mt-2" style="display: 'block';">
                                                    <img id="imagePreview" src="<?php echo e(asset('cms_images/weight/featherweights/'.$featherweightData->weight_class_image)); ?>" alt="Current Image" style="width: 100px; height: 100px; border-radius: 8px;">
                                                </div>
                                                <?php else: ?>
                                                <div id="imagePreviewWrapper" class="mt-2" style="display: 'none';">
                                                    <img id="imagePreview" src="<?php echo e(asset('admin/img/shop-img/no_image.png')); ?>" alt="Current Image" style="width: 100px; height: 100px; border-radius: 8px;">
                                                </div>
                                                <?php endif; ?>

                                                <?php $__errorArgs = ['weight_class_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center mt-4">
                                        <button type="submit" class="ct_custom_btn1 mx-auto">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    ClassicEditor
        .create(document.querySelector('#weight_class_description'), {
            toolbar: [
                'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', 'insertTable', '|', 'undo', 'redo'
                // Add other items as needed, but exclude 'imageUpload' and 'mediaEmbed'
            ],
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    $(document).ready(function() {
        $('#editThinkercad').validate({
            ignore: [],
            rules: {
                weight_class_title: {
                    required: true,
                    maxlength: 150, // Ensure the length is within 150 characters
                },
                weight_class_description: {
                    required: true,
                },
            },
            messages: {
                weight_class_title: {
                    required: "The weight class title is required.",
                    maxlength: "The weight class title must not exceed 150 characters.",
                },
                weight_class_description: {
                    required: "The weight class description is required.",
                },
            },
            errorPlacement: function(error, element) {
                if (element.attr("name") == "weight_class_description") {
                    error.appendTo(element.next());
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<script>
    var loadWeightClassImage = function(event) {
        var image = document.getElementById('imagePreview');
        var wrapper = document.getElementById('imagePreviewWrapper');

        if (event.target.files && event.target.files[0]) {
            image.src = URL.createObjectURL(event.target.files[0]);
            wrapper.style.display = 'block';
        }
    };

    // On page load, handle visibility of the current image
    document.addEventListener('DOMContentLoaded', function() {
        var wrapper = document.getElementById('imagePreviewWrapper');
        var image = document.getElementById('imagePreview');
        wrapper.style.display = image.src ? 'block' : 'none';
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\robot-combot-101\resources\views/admin/content_management/weight_classes/featherweight/edit.blade.php ENDPATH**/ ?>