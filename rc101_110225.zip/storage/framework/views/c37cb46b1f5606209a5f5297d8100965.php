
<?php $__env->startSection('content'); ?>

<!-- Main Content Area -->
<div class="main-content introduction-farm">
    <div class="content-wraper-area">
        <div class="dashboard-area">
            <div class="container-fluid">
                <div class="row g-4">

                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <?php if(Session::has('error_msg')): ?>
                                <div class="alert alert-danger"> <?php echo e(Session::get('error_msg')); ?> </div>
                                <?php endif; ?>

                                <?php if(Session::has('success_msg')): ?>
                                <div class="alert alert-success"> <?php echo e(Session::get('success_msg')); ?> </div>
                                <?php endif; ?>
                                <div
                                    class="card-title border-bootom-none mb-30 d-flex align-items-center justify-content-between">
                                    <h3 class="mb-0 ct_fs_22">Edit Services</h3>
                                    <a href="<?php echo e(url('cms/service-list')); ?>"> <button class="ct_custom_btn1 mx-auto"> Back to List </button> </a>
                                </div>
                                <form action="<?php echo e(url('cms/service-update')); ?>" method="POST" id="editService" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo e($serviceData->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="" class="mb-2">Service Title</label>
                                                <input type="text" class="form-control ct_input" name="service_title" placeholder="Service Title" value="<?php echo e(old('service_title', $serviceData->service_title)); ?>">
                                                <?php $__errorArgs = ['service_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="service_description" class="mb-2">Service Description</label>
                                                <textarea rows="4" class="form-control" name="service_description" id="service_description" placeholder="Service Description"><?php echo e(old('service_description', $serviceData->service_description)); ?></textarea>
                                                <?php $__errorArgs = ['service_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="" class="mb-2"><strong>Service Image</strong></label>
                                                <input name="service_image" type="file" class="form-control ct_input" onchange="loadServiceImage(event)" accept="image/*">

                                                <?php if(!empty($serviceData->service_image) && file_exists(public_path('cms_images/services/' . $serviceData->service_image))): ?>

                                                <div id="imagePreviewWrapper" class="mt-2" style="display: 'block';">
                                                    <img id="imagePreview" src="<?php echo e(asset('cms_images/services/'.$serviceData->service_image)); ?>" alt="Current Image" style="width: 100px; height: 100px; border-radius: 8px;">
                                                </div>
                                                <?php else: ?>
                                                <div id="imagePreviewWrapper" class="mt-2" style="display: 'none';">
                                                    <img id="imagePreview" src="<?php echo e(asset('admin/img/shop-img/no_image.png')); ?>" alt="Current Image" style="width: 100px; height: 100px; border-radius: 8px;">
                                                </div>
                                                <?php endif; ?>

                                                <?php $__errorArgs = ['service_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center mt-4">
                                        <button type="submit" class="ct_custom_btn1 mx-auto">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    ClassicEditor
        .create(document.querySelector('#service_description'), {
            toolbar: [
                'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', 'insertTable', '|', 'undo', 'redo'
                // Add other items as needed, but exclude 'imageUpload' and 'mediaEmbed'
            ],
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    $(document).ready(function() {
        $('#editService').validate({
            rules: {
                service_title: {
                    required: true,
                    maxlength: 100,
                },
                service_description: {
                    required: true,
                },
            },
            messages: {
                service_title: {
                    required: "Please enter service title.",
                    maxlength: "The service title must not exceed 100 characters.",
                },
                service_description: 'Please enter service description.',
            },
            errorPlacement: function(error, element) {
                if (element.attr("name") == "service_description") {
                    error.appendTo(element.next());
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<script>
    var loadServiceImage = function(event) {
        var image = document.getElementById('imagePreview'); // The image preview element
        var wrapper = document.getElementById('imagePreviewWrapper'); // The wrapper for the image preview

        if (event.target.files && event.target.files[0]) {
            image.src = URL.createObjectURL(event.target.files[0]); // Set the new image source
            wrapper.style.display = 'block'; // Ensure the wrapper is visible
        }
    };

    // On page load, handle visibility of the current image
    document.addEventListener('DOMContentLoaded', function() {
        var wrapper = document.getElementById('imagePreviewWrapper');
        var image = document.getElementById('imagePreview');
        wrapper.style.display = image.src ? 'block' : 'none';
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\robot-combot-101\resources\views/admin/content_management/services/edit.blade.php ENDPATH**/ ?>