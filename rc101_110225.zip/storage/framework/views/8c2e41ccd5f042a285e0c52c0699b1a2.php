
<?php $__env->startSection('content'); ?>

<!-- Main Content Area -->
<div class="main-content introduction-farm">
    <div class="content-wraper-area">
        <div class="dashboard-area">
            <div class="container-fluid">
                <div class="row g-4">

                    <div class="col-12">
                        <?php if(Session::has('error_msg')): ?>
                        <div class="alert alert-danger"> <?php echo e(Session::get('error_msg')); ?> </div>
                        <?php endif; ?>

                        <?php if(Session::has('success_msg')): ?>
                        <div class="alert alert-success"> <?php echo e(Session::get('success_msg')); ?> </div>
                        <?php endif; ?>
                        <div class="card ">
                            <div class="card-body card-breadcrumb">
                                <div class="page-title-box mb-4">
                                    <h3 class="mb-0 ct_fs_22">Terms and Conditions</h3>
                                </div>
                                <form action="<?php echo e(url('cms/update-terms-and-conditions')); ?>" method="POST" id="glossaryTermForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($glossaryTerm->id ?? null); ?>">
                                    <div class="mb-3">
                                        <label for=""><strong>Title</strong></label>
                                        <input name="glossary_term_title" type="text" class="form-control ct_input" placeholder="Title" value="<?php echo e(old('glossary_term_title', $glossaryTerm->glossary_term_title ?? '')); ?>">
                                        <?php $__errorArgs = ['glossary_term_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="glossary_term_description"><strong>Description</strong></label>
                                        <textarea name="glossary_term_description" id="glossary_term_description" class="form-control" cols="30" rows="5" placeholder="Description"><?php echo e(old('glossary_term_description', $glossaryTerm->glossary_term_description ?? '')); ?></textarea>
                                        <?php $__errorArgs = ['glossary_term_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="text-center mt-5">
                                        <button type="submit" class="ct_custom_btn1 mx-auto">Save</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    ClassicEditor
        .create(document.querySelector('#glossary_term_description'), {
            toolbar: [
                'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', 'insertTable', '|', 'undo', 'redo'
                // Add other items as needed, but exclude 'imageUpload' and 'mediaEmbed'
            ],
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    $(document).ready(function() {
        $('#glossaryTermForm').validate({
            ignore: [],
            rules: {
                glossary_term_title: {
                    required: true,
                    maxlength: 100,
                },
                glossary_term_description: {
                    required: true,
                },
            },
            messages: {
                glossary_term_title: {
                    required: "Please enter glossary terms title.",
                    maxlength: "The glossary terms title must not exceed 100 characters.",
                },
                glossary_term_description: "Please enter glossary terms content.",
            },
            errorPlacement: function(error, element) {
                if (element.attr("name") == "glossary_term_description") {
                    error.appendTo(element.next());
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\robot-combot-101\resources\views/admin/content_management/glossary_term.blade.php ENDPATH**/ ?>