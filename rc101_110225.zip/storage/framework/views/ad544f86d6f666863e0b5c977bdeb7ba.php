<!DOCTYPE html>

<html class="loading <?php if(auth()->guard()->check()): ?> <?php echo e(auth()->user()->theam_mode); ?> <?php endif; ?>" lang="en" data-textdirection="ltr">

<head>
    <meta charset="utf-8">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('admin/img/logo/logo.png')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title -->
    <title><?php echo e(config('app.name')); ?> | Admin</title>
    <?php echo $__env->make('admin.layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader">
            <svg width="240" height="240" viewBox="0 0 240 240">
                <circle class="loader-ring loader-ring-a" cx="120" cy="120" r="105" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 660" stroke-dashoffset="-330" stroke-linecap="round"></circle>
                <circle class="loader-ring loader-ring-b" cx="120" cy="120" r="35" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 220" stroke-dashoffset="-110" stroke-linecap="round"></circle>
                <circle class="loader-ring loader-ring-c" cx="85" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round"></circle>
                <circle class="loader-ring loader-ring-d" cx="155" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round"></circle>
            </svg>
        </div>

    </div>
    <!-- /Preloader -->
    <div class="flapt-page-wrapper">
        <!-- BEGIN: Main Menu-->
        <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Main Menu-->
        <div class="flapt-page-content">
            <!-- BEGIN: Header-->
            <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- END: Header-->
            <!-- BEGIN: Content-->
            <?php echo $__env->yieldContent('content'); ?>

            <!-- END: Content-->
        </div>
    </div>

    <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\robot-combot-101\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>