<!-- Footer Area -->
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Footer Area -->
            <footer
                class="footer-area d-sm-flex justify-content-center align-items-center justify-content-center">
                <!-- Copywrite Text -->

                <div class="footer-icon text-center">
                    <p class="mb-0 font-13">&copy; {{ date('Y') }} {{ config('app.name') }} | Admin. All rights reserved.</p>
                </div>
            </footer>
        </div>
    </div>
</div>