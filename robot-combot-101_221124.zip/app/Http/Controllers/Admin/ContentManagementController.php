<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ContentManagementController extends Controller
{
    // this method is used to view for home content banner
    public function editHome()
    {
        $data['homeBanner'] = DB::table('cms_home_page')->first();
        return view('admin.content_management.home', $data);
    }

    // this method is used to insert or update home content banner
    public function updateHome(Request $request)
    {
        $request->validate([
            'banner_image' => 'image',
            'youtube_image' => 'image',
        ]);

        $cmsHomeData = [
            'banner_title' => $request->input('banner_title', ''),
            'banner_text' => $request->input('banner_text', ''),
            'media_content' => $request->input('media_content', ''),
            'link' => $request->input('link', ''),
        ];

        if ($request->hasFile('banner_image')) {
            $banner_image = $request->file('banner_image');
            $fileName = uniqid() . '.' . $banner_image->getClientOriginalExtension();
            $banner_image->move(public_path('cms_images'), $fileName);

            $cmsHomeData['banner_image'] = $fileName;
        }

        if ($request->hasFile('youtube_image')) {
            $youtube_image = $request->file('youtube_image');
            $fileName = uniqid() . '.' . $youtube_image->getClientOriginalExtension();
            $youtube_image->move(public_path('cms_images'), $fileName);

            $cmsHomeData['youtube_image'] = $fileName;
        }

        $id = $request->id;

        if ($id) {
            $cmsHomeBanner = DB::table('cms_home_page')->find($id);

            if ($cmsHomeBanner) {
                DB::table('cms_home_page')->where('id', $id)->update($cmsHomeData);
                $message = 'Home banner section updated successfully!';
            } else {
                return redirect('cms/home')->with('error_msg', 'No record found with the provided ID.');
            }
        } else {
            $id = DB::table('cms_home_page')->insertGetId($cmsHomeData);
            $message = 'New home banner section added successfully!';
        }

        return redirect('cms/home')->with($id ? 'success_msg' : 'error_msg', $message);
    }

    // this method is used to view for about section
    public function editAbout()
    {
        $data['aboutSection'] = DB::table('cms_about_page')->first();
        return view('admin.content_management.about', $data);
    }

    // this method is used to insert or update about page
    public function updateAbout(Request $request)
    {
        $request->validate([
            'about_banner' => 'file|mimes:jpeg,png,gif,mp4,mov,avi',
        ]);

        $cmsAboutData = [
            'about_title' => $request->input('about_title', ''),
            'about_content' => $request->input('about_content', ''),
        ];

        if ($request->hasFile('about_banner')) {
            $about_banner = $request->file('about_banner');
            $fileName = uniqid() . '.' . $about_banner->getClientOriginalExtension();
            $about_banner->move(public_path('cms_images'), $fileName);

            $cmsAboutData['about_banner'] = $fileName;
        }

        $id = $request->id;

        if ($id) {
            $cmsAboutSection = DB::table('cms_about_page')->find($id);

            if ($cmsAboutSection) {
                DB::table('cms_about_page')->where('id', $id)->update($cmsAboutData);
                $message = 'About section updated successfully!';
            } else {
                return redirect('cms/about')->with('error_msg', 'No record found with the provided ID.');
            }
        } else {
            $id = DB::table('cms_about_page')->insertGetId($cmsAboutData);
            $message = 'New about section added successfully!';
        }

        return redirect('cms/about')->with($id ? 'success_msg' : 'error_msg', $message);
    }

    // this method is used to view for league
    public function editLeague()
    {
        $data['leaguePage'] = DB::table('cms_leagues')->first();
        return view('admin.content_management.leagues.league', $data);
    }

    // this method is used to insert or update league page
    public function updateLeague(Request $request)
    {
        $request->validate([
            'banner_title' => 'required|string|max:150',
        ]);

        $cmsLeagueData = [
            'banner_title' => $request->input('banner_title', ''),
            'banner_text' => $request->input('banner_text', ''),
            'about_league_title' => $request->input('about_league_title', ''),
            'about_league_desc' => $request->input('about_league_desc', ''),
            'league_page_title' => $request->input('league_page_title', ''),
            'league_page_desc' => $request->input('league_page_desc', ''),
            'league_youtube_link' => $request->input('league_youtube_link', ''),
            // 'league_media_content' => $request->input('league_media_content', ''),
        ];

        $id = $request->id;

        // Check if updating an existing record
        if ($id) {
            $cmsAboutSection = DB::table('cms_leagues')->find($id);

            if (!$cmsAboutSection) {
                return redirect('cms/league')->with('error_msg', 'No record found with the provided ID.');
            }

            // Handle Banner Image
            if ($request->hasFile('banner_image')) {
                $banner_image = $request->file('banner_image');
                $fileName = uniqid() . '.' . $banner_image->getClientOriginalExtension();
                $banner_image->move(public_path('cms_images/leagues'), $fileName);

                // Remove old image if exists
                if ($cmsAboutSection->banner_image && file_exists(public_path('cms_images/leagues/' . $cmsAboutSection->banner_image))) {
                    unlink(public_path('cms_images/leagues/' . $cmsAboutSection->banner_image));
                }

                $cmsLeagueData['banner_image'] = $fileName;
            }

            // Handle League Cover Image
            if ($request->hasFile('league_cover_image')) {
                $league_cover_image = $request->file('league_cover_image');
                $fileName = uniqid() . '.' . $league_cover_image->getClientOriginalExtension();
                $league_cover_image->move(public_path('cms_images/leagues'), $fileName);

                // Remove old image if exists
                if ($cmsAboutSection->league_cover_image && file_exists(public_path('cms_images/leagues/' . $cmsAboutSection->league_cover_image))) {
                    unlink(public_path('cms_images/leagues/' . $cmsAboutSection->league_cover_image));
                }

                $cmsLeagueData['league_cover_image'] = $fileName;
            }

            DB::table('cms_leagues')->where('id', $id)->update($cmsLeagueData);
            $message = 'League page details updated successfully!';
        } else {
            // Insert new record
            if ($request->hasFile('banner_image')) {
                $banner_image = $request->file('banner_image');
                $fileName = uniqid() . '.' . $banner_image->getClientOriginalExtension();
                $banner_image->move(public_path('cms_images/leagues'), $fileName);

                $cmsLeagueData['banner_image'] = $fileName;
            }

            if ($request->hasFile('league_cover_image')) {
                $league_cover_image = $request->file('league_cover_image');
                $fileName = uniqid() . '.' . $league_cover_image->getClientOriginalExtension();
                $league_cover_image->move(public_path('cms_images/leagues'), $fileName);

                $cmsLeagueData['league_cover_image'] = $fileName;
            }

            $id = DB::table('cms_leagues')->insertGetId($cmsLeagueData);
            $message = 'League page details added successfully!';
        }

        return redirect('cms/league')->with($id ? 'success_msg' : 'error_msg', $message);
    }
}
