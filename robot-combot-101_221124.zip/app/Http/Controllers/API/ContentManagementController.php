<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Leader;
use App\Models\Lesson3dModeling;
use App\Models\Lesson3dPrinting;
use App\Models\LessonBatteries;
use App\Models\LessonBescs;
use App\Models\LessonBrushedBrushless;
use App\Models\LessonElectricalEngineering;
use App\Models\LessonGearRatios;
use App\Models\LessonMaterialScience;
use App\Models\LessonPcbs;
use App\Models\LessonPhysicsGeometry;
use App\Models\LessonReceivers;
use App\Models\LessonSlicing;
use App\Models\LessonSoldering;
use App\Models\LessonThinkercad;
use App\Models\LessonWeaponPhysics;
use App\Models\Partner;
use App\Models\Presentation;
use App\Models\Service;
use App\Models\Tournament;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ContentManagementController extends Controller
{
    /**
     * Write code on this method for get about page detail
     *
     * @return response()
     */
    public function getAboutSection()
    {
        $aboutSection = DB::table('cms_about_page')->orderBy('id', 'DESC')->first();

        if ($aboutSection) {
            $aboutSection->about_banner = asset('cms_images/' . $aboutSection->about_banner);
            $response = [
                'success' => true,
                'message' => 'About section retrieved successfully.',
                'data' => $aboutSection,
            ];
            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get home page detail
     *
     * @return response()
     */
    public function getHomeSection()
    {
        $homeSection = DB::table('cms_home_page')->orderBy('id', 'DESC')->first();

        if ($homeSection) {
            $homeSection->banner_image = asset('cms_images/' . $homeSection->banner_image);
            $homeSection->youtube_image = asset('cms_images/' . $homeSection->youtube_image);
            $response = [
                'success' => true,
                'message' => 'Home section retrieved successfully.',
                'data' => $homeSection,
            ];
            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get league page details
     *
     * @return response()
     */
    public function getLeaguePage()
    {
        $leaguePage = DB::table('cms_leagues')->orderBy('id', 'DESC')->first();

        if ($leaguePage) {
            $leaguePage->banner_image = asset('cms_images/leagues/' . $leaguePage->banner_image);
            $leaguePage->league_cover_image = asset('cms_images/leagues/' . $leaguePage->league_cover_image);
            $response = [
                'success' => true,
                'message' => 'League page details retrieved successfully.',
                'data' => $leaguePage,
            ];
            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get all services
     *
     * @return response()
     */
    public function getAllService()
    {
        $services = Service::orderBy('id', 'DESC')->get();

        if ($services->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'No service details found!',
            ], 200);
        }

        // Append full image path to each service
        foreach ($services as $service) {
            $service->service_image = asset('cms_images/' . $service->service_image);
        }

        $response = [
            'success' => true,
            'message' => 'Services retrieved successfully.',
            'data' => $services,
        ];

        return response()->json($response, 200);
    }

    /**
     * Write code on this method for get service details
     *
     * @return response()
     */
    public function getServiceDetails(Request $request)
    {
        $serviceData = Service::where('id', $request->id)
            ->orderBy('id', 'DESC')
            ->first();

        if ($serviceData) {
            $serviceData->service_image = asset('cms_images/' . $serviceData->service_image);
            $response = [
                'success' => true,
                'message' => 'Service details retrieved successfully.',
                'data' => $serviceData,
            ];
            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No service details found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get all partners
     *
     * @return response()
     */
    public function getAllPartner()
    {
        $partners = Partner::orderBy('id', 'DESC')->get();

        if ($partners->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'No company details found!',
            ], 200);
        }

        // Append full image path to each partner
        foreach ($partners as $partner) {
            $partner->company_image = asset('cms_images/' . $partner->company_image);
        }

        $response = [
            'success' => true,
            'message' => 'Partners retrieved successfully.',
            'data' => $partners,
        ];

        return response()->json($response, 200);
    }

    /**
     * Write code on this method for get all leaders
     *
     * @return response()
     */
    public function getAllLeader()
    {
        $leaders = Leader::orderBy('id', 'DESC')->get();

        if ($leaders->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'No leader details found!',
            ], 200);
        }

        // Append full image path to each leader
        foreach ($leaders as $leader) {
            $leader->profile_image = asset('cms_images/' . $leader->profile_image);
        }

        $response = [
            'success' => true,
            'message' => 'Leaders retrieved successfully.',
            'data' => $leaders,
        ];

        return response()->json($response, 200);
    }

    /**
     * Write code on this method for get tournaments
     *
     * @return response()
     */
    public function getAllTournament()
    {
        $tournamentData = Tournament::orderBy('id', 'DESC')->get();

        if ($tournamentData->isNotEmpty()) {
            $tournamentData->transform(function ($tournament) {
                $tournament->banner_image = asset('cms_images/leagues/tournaments/' . $tournament->banner_image);
                return $tournament;
            });

            $response = [
                'success' => true,
                'message' => 'Tournaments retrieved successfully.',
                'data' => $tournamentData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get presentations
     *
     * @return response()
     */
    public function getAllPresentation()
    {
        $presentationData = Presentation::orderBy('id', 'DESC')->get();

        if ($presentationData->isNotEmpty()) {
            $presentationData->transform(function ($presentation) {
                $presentation->presentation_cover_image = asset('cms_images/leagues/presentations/' . $presentation->presentation_cover_image);
                return $presentation;
            });

            $response = [
                'success' => true,
                'message' => 'Presentations retrieved successfully.',
                'data' => $presentationData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get 3d modeling
     *
     * @return response()
     */
    public function getAllLesson3dModeling()
    {
        $modelingData = Lesson3dModeling::orderBy('id', 'DESC')->get();

        if ($modelingData->isNotEmpty()) {
            $modelingData->transform(function ($modeling) {
                $modeling->lesson_cover_image = asset('cms_images/leagues/modeling/' . $modeling->lesson_cover_image);
                return $modeling;
            });

            $response = [
                'success' => true,
                'message' => '3d Modiling retrieved successfully.',
                'data' => $modelingData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get 3d printing
     *
     * @return response()
     */
    public function getAllLesson3dPrinting()
    {
        $printingData = Lesson3dPrinting::orderBy('id', 'DESC')->get();

        if ($printingData->isNotEmpty()) {
            $printingData->transform(function ($printing) {
                $printing->lesson_cover_image = asset('cms_images/leagues/printing/' . $printing->lesson_cover_image);
                return $printing;
            });

            $response = [
                'success' => true,
                'message' => '3d Printing retrieved successfully.',
                'data' => $printingData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get batteries
     *
     * @return response()
     */
    public function getAllLessonBatteries()
    {
        $batteryData = LessonBatteries::orderBy('id', 'DESC')->get();

        if ($batteryData->isNotEmpty()) {
            $batteryData->transform(function ($batteries) {
                $batteries->lesson_cover_image = asset('cms_images/leagues/batteries/' . $batteries->lesson_cover_image);
                return $batteries;
            });

            $response = [
                'success' => true,
                'message' => 'Batteries retrieved successfully.',
                'data' => $batteryData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get escs/bescs
     *
     * @return response()
     */
    public function getAllLessonBescs()
    {
        $bescsData = LessonBescs::orderBy('id', 'DESC')->get();

        if ($bescsData->isNotEmpty()) {
            $bescsData->transform(function ($bescs) {
                $bescs->lesson_cover_image = asset('cms_images/leagues/bescs/' . $bescs->lesson_cover_image);
                return $bescs;
            });

            $response = [
                'success' => true,
                'message' => 'ESCs/BESCs retrieved successfully.',
                'data' => $bescsData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get brushed vs brushless
     *
     * @return response()
     */
    public function getAllLessonBrushedBrushless()
    {
        $brushedBrushlessData = LessonBrushedBrushless::orderBy('id', 'DESC')->get();

        if ($brushedBrushlessData->isNotEmpty()) {
            $brushedBrushlessData->transform(function ($brushedBrushless) {
                $brushedBrushless->lesson_cover_image = asset('cms_images/leagues/brushed_brushless/' . $brushedBrushless->lesson_cover_image);
                return $brushedBrushless;
            });

            $response = [
                'success' => true,
                'message' => 'Brushed vs. Brushless retrieved successfully.',
                'data' => $brushedBrushlessData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get electrical engineering
     *
     * @return response()
     */
    public function getAllLessonElectricalEngineering()
    {
        $electricalEngineeringData = LessonElectricalEngineering::orderBy('id', 'DESC')->get();

        if ($electricalEngineeringData->isNotEmpty()) {
            $electricalEngineeringData->transform(function ($electricalEngineering) {
                $electricalEngineering->lesson_cover_image = asset('cms_images/leagues/electrical_engineering/' . $electricalEngineering->lesson_cover_image);
                return $electricalEngineering;
            });

            $response = [
                'success' => true,
                'message' => 'Electrical Engineering retrieved successfully.',
                'data' => $electricalEngineeringData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }

    /**
     * Write code on this method for get fusion
     *
     * @return response()
     */
    public function getAllLessonFusion()
    {
        $fusionData = LessonElectricalEngineering::orderBy('id', 'DESC')->get();

        if ($fusionData->isNotEmpty()) {
            $fusionData->transform(function ($fusion) {
                $fusion->lesson_cover_image = asset('cms_images/leagues/fusion/' . $fusion->lesson_cover_image);
                return $fusion;
            });

            $response = [
                'success' => true,
                'message' => 'Fusion retrieved successfully.',
                'data' => $fusionData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get gear ratios
     *
     * @return response()
     */
    public function getAllLessonGearRatios()
    {
        $gearRatioData = LessonGearRatios::orderBy('id', 'DESC')->get();

        if ($gearRatioData->isNotEmpty()) {
            $gearRatioData->transform(function ($gearRatio) {
                $gearRatio->lesson_cover_image = asset('cms_images/leagues/gear_ratios/' . $gearRatio->lesson_cover_image);
                return $gearRatio;
            });

            $response = [
                'success' => true,
                'message' => 'Gear Ratios retrieved successfully.',
                'data' => $gearRatioData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get material science
     *
     * @return response()
     */
    public function getAllLessonMaterialScience()
    {
        $materialScienceData = LessonMaterialScience::orderBy('id', 'DESC')->get();

        if ($materialScienceData->isNotEmpty()) {
            $materialScienceData->transform(function ($materialScience) {
                $materialScience->lesson_cover_image = asset('cms_images/leagues/material_science/' . $materialScience->lesson_cover_image);
                return $materialScience;
            });

            $response = [
                'success' => true,
                'message' => 'Material Science retrieved successfully.',
                'data' => $materialScienceData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get PCBs
     *
     * @return response()
     */
    public function getAllLessonPcbs()
    {
        $pcbsData = LessonPcbs::orderBy('id', 'DESC')->get();

        if ($pcbsData->isNotEmpty()) {
            $pcbsData->transform(function ($pcbs) {
                $pcbs->lesson_cover_image = asset('cms_images/leagues/pcbs/' . $pcbs->lesson_cover_image);
                return $pcbs;
            });

            $response = [
                'success' => true,
                'message' => 'PCBs retrieved successfully.',
                'data' => $pcbsData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get physics geometry
     *
     * @return response()
     */
    public function getAllLessonPhysicsGeometry()
    {
        $physicsGeometryData = LessonPhysicsGeometry::orderBy('id', 'DESC')->get();

        if ($physicsGeometryData->isNotEmpty()) {
            $physicsGeometryData->transform(function ($physicsGeometry) {
                $physicsGeometry->lesson_cover_image = asset('cms_images/leagues/physics_geometry/' . $physicsGeometry->lesson_cover_image);
                return $physicsGeometry;
            });

            $response = [
                'success' => true,
                'message' => 'Physics Geometry retrieved successfully.',
                'data' => $physicsGeometryData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get receivers
     *
     * @return response()
     */
    public function getAllLessonReceivers()
    {
        $receiversData = LessonReceivers::orderBy('id', 'DESC')->get();

        if ($receiversData->isNotEmpty()) {
            $receiversData->transform(function ($receivers) {
                $receivers->lesson_cover_image = asset('cms_images/leagues/receivers/' . $receivers->lesson_cover_image);
                return $receivers;
            });

            $response = [
                'success' => true,
                'message' => 'Receivers retrieved successfully.',
                'data' => $receiversData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get slicing
     *
     * @return response()
     */
    public function getAllLessonSlicing()
    {
        $slicingData = LessonSlicing::orderBy('id', 'DESC')->get();

        if ($slicingData->isNotEmpty()) {
            $slicingData->transform(function ($slicing) {
                $slicing->lesson_cover_image = asset('cms_images/leagues/slicing/' . $slicing->lesson_cover_image);
                return $slicing;
            });

            $response = [
                'success' => true,
                'message' => 'Slicing retrieved successfully.',
                'data' => $slicingData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get soldering
     *
     * @return response()
     */
    public function getAllLessonSoldering()
    {
        $solderingData = LessonSoldering::orderBy('id', 'DESC')->get();

        if ($solderingData->isNotEmpty()) {
            $solderingData->transform(function ($soldering) {
                $soldering->lesson_cover_image = asset('cms_images/leagues/soldering/' . $soldering->lesson_cover_image);
                return $soldering;
            });

            $response = [
                'success' => true,
                'message' => 'Soldering retrieved successfully.',
                'data' => $solderingData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get thinkercad
     *
     * @return response()
     */
    public function getAllLessonThinkercad()
    {
        $thinkercadData = LessonThinkercad::orderBy('id', 'DESC')->get();

        if ($thinkercadData->isNotEmpty()) {
            $thinkercadData->transform(function ($thinkercad) {
                $thinkercad->lesson_cover_image = asset('cms_images/leagues/thinkercad/' . $thinkercad->lesson_cover_image);
                return $thinkercad;
            });

            $response = [
                'success' => true,
                'message' => 'Thinkercad retrieved successfully.',
                'data' => $thinkercadData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
    
    /**
     * Write code on this method for get weapon physics
     *
     * @return response()
     */
    public function getAllLessonWeaponPhysics()
    {
        $weaponPhysicsData = LessonWeaponPhysics::orderBy('id', 'DESC')->get();

        if ($weaponPhysicsData->isNotEmpty()) {
            $weaponPhysicsData->transform(function ($weaponPhysics) {
                $weaponPhysics->lesson_cover_image = asset('cms_images/leagues/weapon_physics/' . $weaponPhysics->lesson_cover_image);
                return $weaponPhysics;
            });

            $response = [
                'success' => true,
                'message' => 'Weapon Physics retrieved successfully.',
                'data' => $weaponPhysicsData,
            ];

            return response()->json($response, 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No data found!',
            ], 200);
        }
    }
}
