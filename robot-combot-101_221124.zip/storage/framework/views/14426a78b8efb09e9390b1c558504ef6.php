
<?php $__env->startSection('content'); ?>

<!-- Main Content Area -->
<div class="main-content introduction-farm">
    <div class="content-wraper-area">
        <div class="dashboard-area">
            <div class="container-fluid">
                <div class="row g-4">

                    <div class="col-12">
                        <?php if(Session::has('error_msg')): ?>
                        <div class="alert alert-danger"> <?php echo e(Session::get('error_msg')); ?> </div>
                        <?php endif; ?>

                        <?php if(Session::has('success_msg')): ?>
                        <div class="alert alert-success"> <?php echo e(Session::get('success_msg')); ?> </div>
                        <?php endif; ?>
                        <div class="card ">
                            <div class="card-body card-breadcrumb">
                                <div class="page-title-box mb-4">
                                    <h3 class="mb-0 ct_fs_22">About Section</h3>
                                </div>
                                <form action="<?php echo e(url('cms/update-about')); ?>" method="POST" id="aboutSectionForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($aboutSection->id ?? null); ?>">
                                    <div class="mb-3">
                                        <label for=""><strong>Title</strong></label>
                                        <input name="about_title" type="text" class="form-control ct_input" placeholder="About Title" value="<?php echo e(old('about_title', $aboutSection->about_title ?? '')); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="about_content"><strong>About Content</strong></label>
                                        <textarea name="about_content" id="about_content" class="form-control" cols="30" rows="5" placeholder="About Description"><?php echo e(old('about_content', $aboutSection->about_content ?? '')); ?></textarea>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <label for="about_banner" class="mb-2"><strong>Banner Image</strong></label>
                                        <input name="about_banner" type="file" class="form-control ct_input" onchange="loadBannerImage(event)" accept="image/*">

                                        <img
                                            id="about_banner"
                                            src="<?php echo e($aboutSection && $aboutSection->about_banner ? asset('cms_images/' . $aboutSection->about_banner) : ''); ?>"
                                            style="width: 100px; height: 100px; border-radius: 8px; display: <?= $aboutSection && $aboutSection->about_banner ? 'block' : 'none' ?>"
                                            class="mt-2">

                                        <?php $__errorArgs = ['about_banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="text-center mt-5">
                                        <button type="submit" class="ct_custom_btn1 mx-auto">Save</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    ClassicEditor
        .create(document.querySelector('#about_content'), {
            toolbar: [
                'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', 'insertTable', '|', 'undo', 'redo'
                // Add other items as needed, but exclude 'imageUpload' and 'mediaEmbed'
            ],
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    $(document).ready(function() {
        $('#aboutSectionForm').validate({
            rules: {
                about_title: {
                    required: true,
                },
                about_content: {
                    required: true,
                },
            },
            messages: {
                about_title: 'Please enter about title.',
                about_content: "Please enter about content.",
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<script>
    var loadBannerImage = function(event) {
        var image = document.getElementById('about_banner');
        if (event.target.files && event.target.files[0]) {
            image.src = URL.createObjectURL(event.target.files[0]);
            image.style.display = 'block';
        }
    };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\robot-combot-101\resources\views/admin/content_management/about.blade.php ENDPATH**/ ?>