
<?php $__env->startSection('content'); ?>
<div class="main-content introduction-farm">
    <div class="content-wraper-area">
        <div class="dashboard-area">
            <div class="container-fluid">
                <div class="row g-4">
                    <?php if(Session::has('error_msg')): ?>
                    <div class="alert alert-danger"> <?php echo e(Session::get('error_msg')); ?> </div>
                    <?php endif; ?>

                    <?php if(Session::has('success_msg')): ?>
                    <div class="alert alert-success"> <?php echo e(Session::get('success_msg')); ?> </div>
                    <?php endif; ?>
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="card-title border-bootom-none mb-30 d-flex align-items-center justify-content-between">
                                    <h6 class="mb-0">All Services</h6>
                                    <a href="<?php echo e(url('cms/service-add')); ?>">
                                        <button class="ct_custom_btn1 mx-auto">Add New Service</button>
                                    </a>
                                </div>

                                <table class="table service-data-table table-responsive table-bordered table-hover mb-0" id="serviceTable">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Service Image</th>
                                            <th>Title</th>
                                            <th width="100px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- geting this result from dataTable -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function() {
        var table = $('.service-data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(url('cms/service-list')); ?>",
            columns: [{
                    data: 'serial_number',
                    name: 'serial_number'
                }, // Change 'id' to 'serial_number'
                {
                    data: 'service_image',
                    name: 'service_image'
                },
                {
                    data: 'service_title',
                    name: 'service_title'
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                },
            ]
        });
    });
</script>
<script>
    function deleteConfirm(id) {
        bootbox.confirm({
            closeButton: false,
            message: '<p class="text-center mb-0" style="font-size: 20px;">Are you sure you want to delete?</p>',
            buttons: {
                'cancel': {
                    label: 'No',
                    className: 'btn-danger'
                },
                'confirm': {
                    label: 'Yes',
                    className: 'btn-success'
                }
            },
            callback: function(result) {
                if (result) {
                    $.ajax({
                        url: "<?php echo e(url('cms/service-delete')); ?>",
                        type: "POST",
                        cache: false,
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            id: id
                        },
                        success: function(response) {
                            if (response.error) {
                                toastr.error(response.error);
                            } else {
                                toastr.success(response.message);
                                $('#serviceTable').DataTable().ajax.reload(null, false);
                            }
                        },
                        error: function(xhr, textStatus, errorThrown) {
                            if (xhr.status === 422) {
                                toastr.error(xhr.responseJSON.error);
                            } else if (xhr.status === 404) {
                                toastr.error(xhr.responseJSON.error);
                            } else {
                                toastr.error('An error occurred while processing your request.');
                            }
                        }

                    });
                }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\robot-combot-101\resources\views/admin/content_management/services/list.blade.php ENDPATH**/ ?>