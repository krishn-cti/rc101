<?php $__env->startSection('content'); ?>

<!-- Main Content Area -->
<div class="main-content introduction-farm">
    <div class="content-wraper-area">
        <div class="dashboard-area">
            <div class="container-fluid">
                <div class="row g-4">

                    <?php if(Session::has('error_msg')): ?>
                    <div class="alert alert-danger"> <?php echo e(Session::get('error_msg')); ?> </div>
                    <?php endif; ?>

                    <?php if(Session::has('success_msg')): ?>
                    <div class="alert alert-success"> <?php echo e(Session::get('success_msg')); ?> </div>
                    <?php endif; ?>
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div
                                    class="card-title border-bootom-none mb-30 d-flex align-items-center justify-content-between">
                                    <h3 class="mb-0 ct_fs_22">Edit 3D Printing</h3>
                                    <a href="<?php echo e(url('cms/lessons/3d-printing-list')); ?>"> <button class="ct_custom_btn1 mx-auto"> Back to List </button> </a>
                                </div>
                                <form action="<?php echo e(url('cms/lessons/3d-printing-update')); ?>" method="POST" id="edit3dPrinting" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo e($printingData->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="lesson_title" class="mb-2">Lesson Title</label>
                                                <input type="text" class="form-control ct_input" name="lesson_title" placeholder="Lesson Title" value="<?php echo e(old('lesson_title', $printingData->lesson_title)); ?>">
                                                <?php $__errorArgs = ['lesson_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="lesson_description" class="mb-2">Lesson Description</label>
                                                <textarea rows="4" class="form-control" name="lesson_description" id="lesson_description" placeholder="Lesson Description"><?php echo e(old('lesson_description', $printingData->lesson_description)); ?></textarea>
                                                <?php $__errorArgs = ['lesson_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="lesson_cover_image" class="mb-2">Lesson Cover Image</label>
                                                <input name="lesson_cover_image" type="file" class="form-control ct_input" onchange="loadLessonCoverImage(event)" accept="image/*">

                                                <?php if(!empty($printingData->lesson_cover_image) && file_exists(public_path('cms_images/lesson/printing/' . $printingData->lesson_cover_image))): ?>

                                                <div id="imagePreviewWrapper" class="mt-2" style="display: 'block';">
                                                    <img id="imagePreview" src="<?php echo e(asset('cms_images/lesson/printing/'.$printingData->lesson_cover_image)); ?>" alt="Current Image" style="width: 100px; height: 100px; border-radius: 8px;">
                                                </div>
                                                <?php else: ?>
                                                <div id="imagePreviewWrapper" class="mt-2" style="display: 'none';">
                                                    <img id="imagePreview" src="<?php echo e(asset('admin/img/shop-img/no_image.png')); ?>" alt="Current Image" style="width: 100px; height: 100px; border-radius: 8px;">
                                                </div>
                                                <?php endif; ?>

                                                <?php $__errorArgs = ['lesson_cover_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center mt-4">
                                        <button type="submit" class="ct_custom_btn1 mx-auto">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    ClassicEditor
        .create(document.querySelector('#lesson_description'), {
            toolbar: [
                'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', 'insertTable', '|', 'undo', 'redo'
                // Add other items as needed, but exclude 'imageUpload' and 'mediaEmbed'
            ],
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    $(document).ready(function() {
        $('#edit3dPrinting').validate({
            ignore: [],
            rules: {
                lesson_title: {
                    required: true,
                    maxlength: 150, // Ensure the length is within 150 characters
                },
                lesson_description: {
                    required: true,
                },
            },
            messages: {
                lesson_title: {
                    required: "The lesson title is required.",
                    maxlength: "The lesson title must not exceed 150 characters.",
                },
                lesson_description: {
                    required: "The lesson description is required.",
                },
            },
            errorPlacement: function(error, element) {
                if (element.attr("name") == "lesson_description") {
                    error.appendTo(element.next());
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<script>
    var loadLessonCoverImage = function(event) {
        var image = document.getElementById('imagePreview');
        var wrapper = document.getElementById('imagePreviewWrapper');

        if (event.target.files && event.target.files[0]) {
            image.src = URL.createObjectURL(event.target.files[0]);
            wrapper.style.display = 'block';
        }
    };

    // On page load, handle visibility of the current image
    document.addEventListener('DOMContentLoaded', function() {
        var wrapper = document.getElementById('imagePreviewWrapper');
        var image = document.getElementById('imagePreview');
        wrapper.style.display = image.src ? 'block' : 'none';
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\robot-combot-101\resources\views/admin/content_management/lessons/3d_printing/edit.blade.php ENDPATH**/ ?>