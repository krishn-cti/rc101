
<?php $__env->startSection('content'); ?>

<!-- Main Content Area -->
<div class="main-content introduction-farm">
    <div class="content-wraper-area">
        <div class="dashboard-area">
            <div class="container-fluid">
                <div class="row g-4">

                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <?php if(Session::has('error_msg')): ?>
                                    <div class="alert alert-danger"> <?php echo e(Session::get('error_msg')); ?> </div>
                                <?php endif; ?>
                    
                                <?php if(Session::has('success_msg')): ?>
                                    <div class="alert alert-success"> <?php echo e(Session::get('success_msg')); ?> </div>
                                <?php endif; ?>
                                <div
                                    class="card-title border-bootom-none mb-30 d-flex align-items-center justify-content-between">
                                    <h3 class="mb-0 ct_fs_22">Add Collaborations</h3>
                                    <a href="<?php echo e(url('list-collaboration')); ?>" > <button class="ct_custom_btn1 mx-auto"> Back to List </button> </a>
                                </div>
                                <form action="<?php echo e(url('save-collaboration')); ?>" method="POST" id="addCollaboration" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="" class="mb-2">Company Title</label>
                                                <input type="text" class="form-control" name="company_title" placeholder="Company Title" value="<?php echo e(old('company_title')); ?>">
                                                <?php $__errorArgs = ['company_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="" class="mb-2">Company Website Link</label>
                                                <input type="text" class="form-control" name="web_link" placeholder="Company Website Link" value="<?php echo e(old('web_link')); ?>">
                                                <?php $__errorArgs = ['web_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="" class="mb-2"><strong>Company Image</strong></label>
                                                <input name="company_image" type="file" class="form-control">
                                                <?php $__errorArgs = ['company_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center mt-4">
                                        <button type="submit" class="ct_custom_btn1 mx-auto">Save</button>
                                    </div>  
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
  $(document).ready(function () {
    $('#addCollaboration').validate({
      rules: {
        company_title: {
            required: true,
        },
        web_link: {
            required: true,
        },
      },
      messages: {
        company_title: 'Please enter company title.',
        web_link: 'Please enter company website link.',
      },
      
      submitHandler: function (form) {
        form.submit();
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\advanced-learning\resources\views/admin/content_management/collaboration/add.blade.php ENDPATH**/ ?>