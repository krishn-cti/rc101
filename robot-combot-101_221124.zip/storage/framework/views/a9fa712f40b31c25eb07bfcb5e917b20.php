
<?php $__env->startSection('content'); ?>

<!-- Main Content Area -->
<div class="main-content introduction-farm">
                <div class="content-wraper-area">
                    <div class="dashboard-area">
                        <div class="container-fluid">
                            <div class="row g-4">

                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <div
                                                class="card-title border-bootom-none mb-30 d-flex align-items-center justify-content-between">
                                                <h3 class="mb-0 ct_fs_22">Add Products</h3>
                                                <a href="<?php echo e(url('list-product')); ?>" > <button class="btn btn-info"> Back to List </button> </a>
                                            </div>
                                          <div>
                                            <form action="<?php echo e(url('save-product')); ?>" method="POST" id="addProduct" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                               <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Thumbnail</label>
                                                        <input type="file" class="form-control" name="thumbnail">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Other Images</label>
                                                        <input type="file" class="form-control" multiple name="images[]">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Product Name</label>
                                                        <input type="text" class="form-control" name="product_name" placeholder="Product Name">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Related Name</label>
                                                        <input type="text" class="form-control" name="related_name" placeholder="Related Name">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Category</label>
                                                        <select id="category" name="category_id" class="form-control">
                                                            <option value="">Select Product Category</option>
                                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Sub Category</label>
                                                        <select id="sub_category" name="sub_category_id" class="form-control">
                                                            <option value="">Select Sub Category</option>
                                                            <!-- this data getting from on change of category -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Price</label>
                                                        <input type="number" class="form-control" name="price" placeholder="Price">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Discount</label>
                                                        <input type="number" class="form-control" name="discount" placeholder="Discount">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Quantity</label>
                                                        <input type="number" class="form-control" name="quantity" placeholder="Quantity">
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Short Description</label>
                                                        <textarea rows="4" class="form-control" name="description" placeholder="Short Description"></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group mb-3">
                                                        <label for="" class="mb-2">Long Description</label>
                                                        <textarea id="description" rows="4" class="form-control ckeditor" name="long_description"></textarea>
                                                    </div>
                                                </div>
                                               </div>
                                               <div class="text-center mt-4">
                                                <button type="submit" class="ct_custom_btn1 mx-auto">Save</button>
                                               </div>  
                                            </form>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>  
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script type="text/javascript">
    CKEDITOR.replace( 'description',
    {
    customConfig : 'config.js',
    toolbar : 'simple'
    })
</script> 
<script>
    $(document).ready(function () {
    $('#category').on('change', function () {
        var categoryId = $(this).val();
        if (categoryId) {
            $.ajax({
                url: '<?php echo e(url("subcategories")); ?>',
                type: 'GET',
                data: {category_id: categoryId},
                dataType: 'json',
                success: function (data) {
                    $('#sub_category').empty();
                    $('#sub_category').append('<option value="">Select Sub Category</option>');
                    $.each(data, function (id, name) {
                        $('#sub_category').append('<option value="' + id + '">' + name + '</option>');
                    });
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        } else {
            $('#sub_category').empty();
            $('#sub_category').append('<option value="">Select Sub Category</option>');
        }
    });
});
</script>
<script>
  $(document).ready(function () {
    $('#addProduct').validate({
      rules: {
        thumbnail: {
          required: true
        },
        product_name: {
          required: true,
        },
        related_name: {
          required: true,
        },
        category_id: {
          required: true,
        },
        sub_category_id: {
          required: true,
        },
        price: {
          required: true,
        },
        quantity: {
          required: true,
        },
        description: {
          required: true,
        },
        // number: {
        //   required: true,
        //   rangelength: [10, 12],
        //   number: true
        // }
      },
      messages: {
        thumbnail: 'Please upload thumbnail image.',
        product_name: 'Please enter product name.',
        related_name: 'Please enter related name.',
        category_id: 'Please select category.',
        sub_category_id: 'Please select sub category.',
        price: 'Please enter price.',
        quantity: 'Please enter quantity.',
        description: 'Please enter short description.',
        // number: {
        //   required: 'Please enter Contact.',
        //   rangelength: 'Contact should be 10 digit number.'
        // }
      },
      
      submitHandler: function (form) {
        form.submit();
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\advanced-learning\resources\views/admin/product/add.blade.php ENDPATH**/ ?>