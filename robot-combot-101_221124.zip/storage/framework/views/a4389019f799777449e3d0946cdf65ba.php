<!-- Footer Area -->
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Footer Area -->
            <footer
                class="footer-area d-sm-flex justify-content-center align-items-center justify-content-center">
                <!-- Copywrite Text -->

                <div class="footer-icon text-center">
                    <p class="mb-0 font-13">&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?> | Admin. All rights reserved.</p>
                </div>
            </footer>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\robot-combot-101\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>