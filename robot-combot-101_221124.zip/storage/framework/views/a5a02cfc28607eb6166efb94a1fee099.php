
<?php $__env->startSection('content'); ?>

<!-- Main Content Area -->
<div class="main-content introduction-farm">
    <div class="content-wraper-area">
        <div class="dashboard-area">
            <div class="container-fluid">
                <div class="row g-4">

                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="card-title border-bootom-none mb-30 d-flex align-items-center justify-content-between">
                                    <h3 class="mb-0 ct_fs_22">Edit Product</h3>
                                    <a href="<?php echo e(url('list-product')); ?>"> <button class="ct_custom_btn1 mx-auto"> Back to List </button> </a>
                                </div>
                                <div>
                                    <form action="<?php echo e(url('update-product/'.$product->id)); ?>" method="POST" id="editProduct" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Thumbnail</label>
                                                    <input type="file" class="form-control ct_input" name="thumbnail" accept="image/*" onchange="previewThumbnail(event)">
                                                    <div id="thumbnailPreviewWrapper" class="mt-2">
                                                        <img id="thumbnailPreview"
                                                            src="<?php echo e($product->productImages->thumbnail); ?>"
                                                            alt="Thumbnail Preview"
                                                            style="width: 100px; height: 100px; border-radius: 8px;">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Other Images</label>
                                                    <input type="file" class="form-control ct_input" multiple name="images[]" accept="image/*" onchange="previewImages(event)">
                                                    <div id="imagesPreviewWrapper" class="mt-2 d-flex gap-2" style="flex-wrap: wrap;">
                                                        <!-- Display existing images -->
                                                        <?php if(!empty($other_images)): ?>
                                                        <?php $__currentLoopData = $other_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <img src="<?php echo e($images); ?>" style="width:100px;height:100px; border-radius:8px;">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Product Name</label>
                                                    <input type="text" class="form-control ct_input" name="product_name" value="<?php echo e($product->product_name); ?>" placeholder="Product Name">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Related Name</label>
                                                    <input type="text" class="form-control ct_input" name="related_name" value="<?php echo e($product->related_name); ?>" placeholder="Related Name">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Category</label>
                                                    <select id="category" name="category_id" class="form-control ct_input">
                                                        <option value="">Select Product Category</option>
                                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cat->id); ?>" <?php echo e($product->category_id == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->category_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Sub Category</label>
                                                    <select id="sub_category" name="sub_category_id" class="form-control ct_input">
                                                        <option value="">Select Sub Category</option>
                                                        <!-- this data getting from on change of category -->
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Price</label>
                                                    <input type="number" class="form-control ct_input" name="price" value="<?php echo e($product->price); ?>" placeholder="Price">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Discount</label>
                                                    <input type="number" class="form-control ct_input" name="discount" value="<?php echo e($product->discount); ?>" placeholder="Discount">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Quantity</label>
                                                    <input type="number" class="form-control ct_input" name="quantity" value="<?php echo e($product->quantity); ?>" placeholder="Quantity">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group mb-3">
                                                    <label for="" class="mb-2">Short Description</label>
                                                    <textarea rows="4" class="form-control ct_input" name="description" placeholder="Short Description"><?php echo e($product->description); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group mb-3">
                                                    <label for="long_description" class="mb-2">Long Description</label>
                                                    <textarea id="long_description" rows="4" class="form-control" name="long_description"><?php echo e($product->long_description); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-center mt-4">
                                            <button type="submit" class="ct_custom_btn1 mx-auto">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    ClassicEditor
        .create(document.querySelector('#long_description'), {
            toolbar: [
                'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', 'insertTable', '|', 'undo', 'redo'
                // Add other items as needed, but exclude 'imageUpload' and 'mediaEmbed'
            ],
        })
        .catch(error => {
            console.error(error);
        });
</script>
<script>
    // Function to preview new thumbnail
    function previewThumbnail(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('thumbnailPreview').src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    }

    // Function to preview new multiple images
    function previewImages(event) {
        const files = event.target.files;
        const previewWrapper = document.getElementById('imagesPreviewWrapper');
        previewWrapper.innerHTML = ''; // Clear existing previews

        Array.from(files).forEach((file) => {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.style.width = '100px';
                img.style.height = '100px';
                img.style.borderRadius = '8px';
                img.style.marginRight = '10px';
                previewWrapper.appendChild(img);
            };
            reader.readAsDataURL(file);
        });
    }
</script>
<script>
    $(document).ready(function() {
        $('#category').on('change', function() {
            var categoryId = $(this).val();
            if (categoryId) {
                $.ajax({
                    url: '<?php echo e(url("subcategories")); ?>',
                    type: 'GET',
                    data: {
                        category_id: categoryId
                    },
                    dataType: 'json',
                    success: function(data) {
                        $('#sub_category').empty();
                        $('#sub_category').append('<option value="">Select Sub Category</option>');
                        $.each(data, function(id, name) {
                            $('#sub_category').append('<option value="' + id + '">' + name + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            } else {
                $('#sub_category').empty();
                $('#sub_category').append('<option value="">Select Sub Category</option>');
            }
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('#editProduct').validate({
            rules: {
                thumbnail: {
                    required: false, // Thumbnail is optional during update
                    accept: "image/*" // Ensure it's an image if uploaded
                },
                product_name: {
                    required: true,
                    maxlength: 100,
                },
                related_name: {
                    required: true,
                    maxlength: 100,
                },
                category_id: {
                    required: true,
                },
                sub_category_id: {
                    required: true,
                },
                price: {
                    required: true,
                    number: true, // Ensure price is a valid number
                },
                quantity: {
                    required: true,
                    digits: true, // Ensure quantity is an integer
                },
                description: {
                    required: true,
                    maxlength: 255,
                },
            },
            messages: {
                thumbnail: {
                    accept: 'Please upload a valid image.',
                },
                product_name: {
                    required: 'Please enter product name.',
                    maxlength: 'Product name cannot exceed 100 characters.',
                },
                related_name: {
                    required: 'Please enter related name.',
                    maxlength: 'Related name cannot exceed 100 characters.',
                },
                category_id: 'Please select category.',
                sub_category_id: 'Please select sub category.',
                price: {
                    required: 'Please enter price.',
                    number: 'Please enter a valid number for price.',
                },
                quantity: {
                    required: 'Please enter quantity.',
                    digits: 'Please enter a valid integer for quantity.',
                },
                description: {
                    required: 'Please enter short description.',
                    maxlength: 'Description cannot exceed 255 characters.',
                },
            },

            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\robot-combot-101\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>