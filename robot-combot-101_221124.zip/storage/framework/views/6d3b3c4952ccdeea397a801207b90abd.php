<!-- Footer Area -->
<div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <!-- Footer Area -->
                            <footer
                                class="footer-area d-sm-flex justify-content-center align-items-center justify-content-center">
                                <!-- Copywrite Text -->
                               
                                <div class="fotter-icon text-center">
                                    <p class="mb-0 font-13">2023 &copy; Advanced Learning Admin</p>
                                </div>
                            </footer>
                        </div>
                    </div>
                </div><?php /**PATH C:\xampp\htdocs\advanced-learning\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>