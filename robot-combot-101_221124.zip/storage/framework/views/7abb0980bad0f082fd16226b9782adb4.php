<!-- Sidemenu Area -->
<div class="flapt-sidemenu-wrapper">
    <!-- Desktop Logo -->
    <div class="flapt-logo">
        <!-- <a href="index.html"><img class="desktop-logo" src="img/core-img/logo.png" alt="Desktop Logo"> <img
                class="small-logo" src="img/core-img/small-logo.png" alt="Mobile Logo"></a> -->
                <h4>Advanced Learning</h4>
    </div>

    <!-- Side Nav -->
    <div class="flapt-sidenav" id="flaptSideNav">
        <!-- Side Menu Area -->
        <div class="side-menu-area">
            <!-- Sidebar Menu -->
            <nav>
                <ul id="ct_sidebar" class="sidebar-menu" data-widget="tree">
                    <li class="menu-header-title <?php echo e(request()->is('dashboard') ? 'active' : ''); ?> ps-0"> <a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="menu-header-title <?php echo e(request()->is('list-product', 'add-product', 'edit-product/*') ? 'active' : ''); ?> ps-0">
                        <a href="<?php echo e(url('list-product')); ?>">Products</a>
                    </li>
                    <!-- <li class="menu-header-title ps-0"> <a href="<?php echo e(url('add-product')); ?>">Add Product</a></li> -->
                    <li class="menu-header-title <?php echo e(request()->is('list-category','add-category', 'edit-category/*') ? 'active' : ''); ?> ps-0"> <a href="<?php echo e(url('list-category')); ?>">Categories</a></li>
                    <li class="menu-header-title <?php echo e(request()->is('list-sub-category','add-sub-category', 'edit-sub-category/*') ? 'active' : ''); ?> ps-0"> <a href="<?php echo e(url('list-sub-category')); ?>">Sub Categories</a></li>
                    <li class="menu-header-title <?php echo e(request()->is('list-user','add-user', 'edit-user/*') ? 'active' : ''); ?> ps-0"> <a href="<?php echo e(url('list-user')); ?>">Users</a></li>
                    <li class="menu-header-title <?php echo e(request()->is('list-order') ? 'active' : ''); ?> ps-0"> <a href="<?php echo e(url('list-order')); ?>">Orders</a></li>

                    <li class="menu-header-title treeview ps-0 <?php echo e(request()->is('home-banner', 'about-section', 'list-service', 'add-service', 'edit-service/*', 'list-collaboration', 'add-collaboration', 'edit-collaboration/*', 'list-leader', 'add-leader', 'edit-leader/*') ? 'menu-open active' : ''); ?>">
                        <a href="javascript:void(0)">
                            <span>Content management</span>
                            <i class="fa fa-angle-right"></i>
                        </a>
                        <ul class="treeview-menu">
                            <li class="menu-header-title <?php echo e(request()->is('home-banner') ? 'active' : ''); ?> ps-0">
                                <a href="<?php echo e(url('home-banner')); ?>">Home</a>
                            </li>
                            <li class="menu-header-title <?php echo e(request()->is('about-section') ? 'active' : ''); ?> ps-0">
                                <a href="<?php echo e(url('about-section')); ?>">About</a>
                            </li>
                            <li class="menu-header-title <?php echo e(request()->is('list-service', 'add-service', 'edit-service/*') ? 'active' : ''); ?> ps-0">
                                <a href="<?php echo e(url('list-service')); ?>">Services</a>
                            </li>
                            <li class="menu-header-title <?php echo e(request()->is('list-collaboration', 'add-collaboration', 'edit-collaboration/*') ? 'active' : ''); ?> ps-0">
                                <a href="<?php echo e(url('list-collaboration')); ?>">Collaborations</a>
                            </li>
                            <li class="menu-header-title <?php echo e(request()->is('list-leader', 'add-leader', 'edit-leader/*') ? 'active' : ''); ?> ps-0">
                                <a href="<?php echo e(url('list-leader')); ?>">Our Leaders</a>
                            </li>
                        </ul>
                    </li>

                </ul>

            </nav>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\advanced-learning\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>