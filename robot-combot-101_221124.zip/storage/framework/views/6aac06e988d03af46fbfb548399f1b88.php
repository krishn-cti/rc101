
<?php $__env->startSection('content'); ?>

<!-- Main Content Area -->
<div class="main-content introduction-farm">
    <div class="content-wraper-area">
        <div class="dashboard-area">
            <div class="container-fluid">
                <div class="row g-4">

                    <div class="col-12">
                        <?php if(Session::has('error_msg')): ?>
                            <div class="alert alert-danger"> <?php echo e(Session::get('error_msg')); ?> </div>
                        <?php endif; ?>
            
                        <?php if(Session::has('success_msg')): ?>
                            <div class="alert alert-success"> <?php echo e(Session::get('success_msg')); ?> </div>
                        <?php endif; ?>
                        <div class="card ">
                            <div class="card-body card-breadcrumb">
                                <div class="page-title-box mb-4">
                                    <h3 class="mb-0 ct_fs_22">Home Section</h3>
                                </div>
                                <form action="<?php echo e(url('update-home-banner')); ?>" method="POST" id="homeBannerForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($homeBanner->id ?? null); ?>">
                                    <div class="mb-3">
                                        <label for=""><strong>Banner Title</strong></label>
                                        <input name="banner_title" type="text" class="form-control" placeholder="Banner Title" value="<?php echo e(old('banner_title', $homeBanner->banner_title ?? '')); ?>">
                                        <?php $__errorArgs = ['banner_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for=""><strong>Banner Text</strong></label>
                                        <textarea name="banner_text" class="form-control" cols="30" rows="5" placeholder="Banner Description" required><?php echo e(old('banner_text', $homeBanner->banner_text ?? '')); ?></textarea>
                                        <?php $__errorArgs = ['banner_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for=""><strong>YouTube Link</strong></label>
                                        <input name="link" type="text" class="form-control" value="<?php echo e(old('link', $homeBanner->link ?? '')); ?>" placeholder="Banner Link">
                                        <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for=""><strong>Media Content</strong></label>
                                        <textarea name="media_content" class="form-control ckeditor" cols="30" rows="5" placeholder="Media Content"><?php echo e(old('media_content', $homeBanner->media_content ?? '')); ?></textarea>
                                        <?php $__errorArgs = ['media_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="" class="mb-2"><strong>YouTube Cover Image</strong></label>
                                            <input name="youtube_image" type="file" class="form-control">
                                            <?php if(!empty($homeBanner->youtube_image) && file_exists(public_path('cms_images/' . $homeBanner->youtube_image))): ?>
                                                <img src="<?php echo e(asset('cms_images/' . $homeBanner->youtube_image)); ?>" style="width: 100px; height: 100px;" class="mt-2">
                                            <?php else: ?>
                                                <span>No image available</span>
                                            <?php endif; ?>
                                            
                                            <?php $__errorArgs = ['banner_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="" class="mb-2"><strong>Home Banner Image</strong></label>
                                            <input name="banner_image" type="file" class="form-control">
                                            <?php if(!empty($homeBanner->banner_image) && file_exists(public_path('cms_images/' . $homeBanner->banner_image))): ?>
                                                <img src="<?php echo e(asset('cms_images/' . $homeBanner->banner_image)); ?>" style="width: 100px; height: 100px;" class="mt-2">
                                            <?php else: ?>
                                                <span>No image available</span>
                                            <?php endif; ?>
                                            
                                            <?php $__errorArgs = ['banner_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text text-danger mt-2"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="text-center mt-5">
                                        <button type="submit" class="ct_custom_btn1 mx-auto">Save</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    CKEDITOR.replace( 'banner_text',
    {
        customConfig : 'config.js',
        toolbar : 'simple'
    })
</script> 
<script>
    $(document).ready(function () {

        // Add custom validation method for YouTube links
        $.validator.addMethod("validYouTubeLink", function(value, element) {
            // Regular expression pattern to match YouTube video URLs
            var pattern = /^(?:(?:https?:\/\/)?(?:www\.)?(?:youtube\.com(?:\/[^/\s]+){2,}|youtu\.be\/[^\s/]+))$/;
            return pattern.test(value);
        }, "Please enter a valid YouTube link.");

        $('#homeBannerForm').validate({
            ignore: [],
            debug: false,
            rules: {
                banner_title: {
                    required: true,
                },
                link: {
                    required: true,
                    validYouTubeLink: true // Use custom validation method
                },
            },
            messages: {
                banner_title: 'Please enter banner title.',
                link: {
                    required : 'Please enter YouTube link.',
                    validYouTubeLink : 'Please enter a valid YouTube link.',
                }
            },
            submitHandler: function (form) {
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\advanced-learning\resources\views/admin/content_management/home_banner.blade.php ENDPATH**/ ?>